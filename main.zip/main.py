# ATTRIBUTES OF MY FAVOURITE SONG #

"""
In this project I am going to print all I know about my favourite song.
So lets start...
"""

song_name = "Tum hi ho" # The name of my favourite song #
artist = "Arijit Singh" # Singer of the song #
genre = "Acoustic music, Filmi, Indian pop" # The genre of the song #
language = "Hindi" # The language in which the song is #
release_date = "16th March" # Date of release of the song #
release_year = 2013 # Year of release #
duration = 4.22 # Length of the song  #
writer = "Mithoon" # The writer of the song #
movie = "Aashiqui 2" # The movie in which the song is #
label = "T-Series" # Label of the company from which the song was released #

print(song_name)
print(artist)
print(genre)
print(language)
print(release_date)
print(release_year)
print(duration)
print(writer)
print(movie)
print(label)